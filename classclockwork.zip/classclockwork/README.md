# ClassClockwork – ZeroClash Timetable Generator

Automated college timetable generator. Backtracking CSP solver (MRV heuristic), live clash auditor,
drag-and-drop 5-day x 6-period grid, batch/faculty views, PDF + print + .ics export.

## Run (VS Code)
1. Open this folder in VS Code (`File > Open Folder`).
2. Open `index.html` in a browser, or install the **Live Server** extension, right-click `index.html`
   and choose **Open with Live Server**. No build step or `npm install` needed.
3. Press **Generate Timetable**.

## Test the scheduling engine (needs Node.js)
    npm test

## Folder layout
    index.html          page structure
    css/style.css       styling, dark theme, print layout
    js/core.js          solver (solve), clash auditor (audit), sample data (preset), gini
    js/app.js           UI: resource editor, grid, drag-and-drop, PDF / .ics export
    tests/solver.test.js

## Features
Must-have: resource manager, CSP engine, interactive grid with drag-and-drop, real-time clash
detection in red, batch/faculty toggle, PDF + print export.
Stretch: uniform lunch break, Gini workload metric, .ics export, morning/afternoon preferences.

Data is stored in the browser (localStorage). Fonts load from Google Fonts (optional, works offline).
