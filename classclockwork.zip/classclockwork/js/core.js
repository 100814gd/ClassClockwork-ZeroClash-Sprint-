/* Scheduling engine (CSP backtracking + MRV), clash auditor, sample data, Gini.
   No DOM access, so it can be tested in Node. */
const D=['Mon','Tue','Wed','Thu','Fri'],ALL=[0,1,2,3,4,5],WK=[0,1,2,3,4];
let _id=1;const uid=()=>_id++;
const blk=(ds,ps)=>ds.flatMap(d=>ps.map(p=>d*6+p));
function preset(n){
 const F=(name,max,pref,off=[])=>({id:uid(),name,max,pref,off}),R=(name,cap,lab=false)=>({id:uid(),name,cap,lab}),B=(name,size)=>({id:uid(),name,size});
 let fa,ro,ba,sp;
 if(n==1){
  fa=[F('Dr. Sharma',14,'M'),F('Dr. Iyer',14,''),F('Prof. Rao',12,'',blk([4],ALL)),F('Dr. Khan',14,'A',blk([2],[3,4,5])),F('Prof. Mehta',12,'M',blk(WK,[3,4,5])),F('Dr. Nair',14,''),F('Prof. Singh',10,'A',blk([0,1],[0,1])),F('Dr. Das',14,'',blk([3],ALL)),F('Prof. Bose',12,'M'),F('Dr. Kapoor',14,'A')];
  sp=[['Data Structures','CS201',3,2,4,[0,1,5]],['Operating Systems','CS202',2,3,4,[1,3,9]],['Database Systems','CS203',2,2,4,[2,5,6]],['Computer Networks','CS204',3,0,3,[3,4]],['Algorithms','CS205',3,0,3,[0,7,8]],['Software Engg.','CS206',2,0,2,[4,6,8]],['Discrete Maths','MA201',2,0,2,[2,7]],['Prof. Communication','HS201',2,0,2,[6,9]]];
  ro=[R('Room 101',70),R('Room 102',70),R('Room 103',60),R('Room 104',40),R('Lab 1',65,true),R('Lab 2',65,true)];
  ba=[B('CS-A',60),B('CS-B',56),B('CS-C',52)];
 }else{
  fa=[F('Dr. Sharma',14,'M'),F('Prof. Verma',12,''),F('Dr. Patel',12,'A'),F('Prof. Reddy',12,''),F('Dr. Joshi',12,'',blk([4],ALL))];
  sp=[['Operating Systems','CS301',2,3,4,[0,3]],['Data Structures','CS302',3,0,3,[0,1]],['Database Systems','CS303',3,0,3,[1,2]],['Computer Networks','CS304',2,0,3,[2,3]],['Engg. Maths','MA301',3,0,3,[0,4]],['English','HS301',2,0,2,[4,1]]];
  ro=[R('Room 101',60),R('Room 102',60),R('Lab A',60,true),R('Room 104',30)];
  ba=[B('CS-A',55),B('CS-B',50)];
 }
 return{subjects:sp.map(([name,code,lec,lab,cr,f])=>({id:uid(),name,code,lec,lab,cr,fac:f.map(i=>fa[i].id)})),faculty:fa,rooms:ro,batches:ba,lunch:3};
}
/* ---- Backtracking CSP solver with MRV + forward checking ---- */
function solve(S,budget=1400,seed=1){
 const t0=performance.now(),SU=S.subjects,FA=S.faculty,RO=S.rooms,BA=S.batches,LA=S.lunch,sess=[];
 BA.forEach((b,bi)=>SU.forEach((s,si)=>{for(let i=0;i<s.lec;i++)sess.push({bi,si,kind:'lec',len:1});if(s.lab>0)sess.push({bi,si,kind:'lab',len:+s.lab})}));
 const N=sess.length,fx={};FA.forEach((f,i)=>fx[f.id]=i);
 const cand=sess.map(x=>{const b=BA[x.bi],c=[];
  for(let st=0;st<30;st++){const p=st%6;if(p+x.len>6||(p<LA&&p+x.len>LA))continue;
   for(const fid of SU[x.si].fac){const fi=fx[fid];if(fi===undefined)continue;const f=FA[fi];if(x.len>f.max)continue;
    let free=true;for(let j=0;j<x.len;j++)if(f.off.includes(st+j))free=false;if(!free)continue;
    RO.forEach((r,ri)=>{if(!!r.lab===(x.kind==='lab')&&r.cap>=b.size)c.push([st,fi,ri])})}}
  return c});
 const skip=cand.map(c=>!c.length);let nodes=0,bestAsg=null,bestCnt=-1;
 function attempt(sd,bud){
  let r=sd;const rnd=()=>(r=(r*1664525+1013904223)>>>0)/4294967296;
  const bB=new Uint8Array(BA.length*30),fB=new Uint8Array(FA.length*30),rB=new Uint8Array(RO.length*30),load=new Array(FA.length).fill(0),dl=new Uint8Array(BA.length*5),sd2=new Uint8Array(BA.length*SU.length*5),asg=new Array(N).fill(null);
  const ok=(k,c,relax)=>{const x=sess[k],st=c[0],fi=c[1],ri=c[2],b=x.bi,d=st/6|0;
   if(load[fi]+x.len>FA[fi].max)return false;
   if(!relax&&x.kind==='lec'&&sd2[(b*SU.length+x.si)*5+d])return false;
   for(let j=0;j<x.len;j++){const q=st+j;if(bB[b*30+q]||fB[fi*30+q]||rB[ri*30+q])return false}return true};
  const put=(k,c,v)=>{const x=sess[k],st=c[0],fi=c[1],ri=c[2],d=st/6|0;
   for(let j=0;j<x.len;j++){const q=st+j;bB[x.bi*30+q]=fB[fi*30+q]=rB[ri*30+q]=v}
   load[fi]+=v?x.len:-x.len;dl[x.bi*5+d]+=v?x.len:-x.len;if(x.kind==='lec')sd2[(x.bi*SU.length+x.si)*5+d]=v};
  const sc=(k,c)=>{const x=sess[k],p=c[0]%6,f=FA[c[1]];let s=load[c[1]]*.4+dl[x.bi*5+(c[0]/6|0)]*.8+rnd()*.6;
   if(f.pref=='M'&&p>=LA)s+=2;if(f.pref=='A'&&p<LA)s+=2;if(x.kind=='lab'&&p<LA)s+=1;return s};
  let tmo=false,cnt=0;const total=skip.filter(s=>!s).length;
  function rec(depth){
   if(depth>cnt){cnt=depth;if(cnt>bestCnt){bestCnt=cnt;bestAsg=asg.slice()}}
   if(depth===total)return true;
   if(performance.now()-t0>bud||++nodes>3e5){tmo=true;return false}
   let bk=-1,bn=1e9,bl=null;
   for(let k=0;k<N;k++){if(asg[k]||skip[k])continue;let n=0;const l=[];
    for(const c of cand[k])if(ok(k,c)){l.push(c);if(++n>bn)break}
    if(!n)return false;
    if(n<bn||(n===bn&&sess[k].len>sess[bk].len)){bk=k;bn=n;bl=l}}
   const scored=bl.map(c=>[sc(bk,c),c]).sort((a,b)=>a[0]-b[0]);
   for(const [,c] of scored){asg[bk]=c;put(bk,c,1);if(rec(depth+1))return true;put(bk,c,0);asg[bk]=null;if(tmo)return false}
   return false}
  const done=rec(0);
  if(!done){ // relaxation: restore best partial, then greedily fill what is left
   const from=bestAsg||asg;for(let k=0;k<N;k++)if(from[k]&&!asg[k]){asg[k]=from[k];put(k,from[k],1)}
   const rest=[];for(let k=0;k<N;k++)if(!asg[k]&&!skip[k])rest.push(k);rest.sort((a,b)=>sess[b].len-sess[a].len);
   for(const k of rest){let bc=null,bs=1e9;for(const c of cand[k])if(ok(k,c,true)){const s=sc(k,c);if(s<bs){bs=s;bc=c}}if(bc){asg[k]=bc;put(k,bc,1)}}}
  return asg};
 let best=null,bestN=-1;
 for(let a=0;a<3&&bestN<total_(skip);a++){const asg=attempt(seed+a*7919,Math.max(150,budget/3));const n=asg.filter(Boolean).length;if(n>bestN){bestN=n;best=asg}bestAsg=null;bestCnt=-1}
 function total_(s){return s.filter(x=>!x).length}
 const A=[],U=[];
 sess.forEach((x,k)=>{const c=best[k],s=SU[x.si],b=BA[x.bi];
  if(c)A.push({id:uid(),batch:b.id,subj:s.id,kind:x.kind,len:x.len,day:c[0]/6|0,p:c[0]%6,fac:FA[c[1]].id,room:RO[c[2]].id});
  else U.push({batch:b.id,subj:s.id,kind:x.kind,len:x.len,why:skip[k]?(!s.fac.length?'No eligible faculty assigned':!RO.some(r=>!!r.lab===(x.kind=='lab')&&r.cap>=b.size)?'No room with enough seats'+(x.kind=='lab'?' and lab equipment':''):'Faculty availability/workload leaves no valid slot'):'No conflict-free slot found within the retry limit'})});
 return{A,U,ms:Math.round(performance.now()-t0),nodes};
}
/* ---- Clash detection auditor ---- */
function audit(S,A){
 const V=[],seen=new Set(),by={},nm=(l,id)=>(S[l].find(x=>x.id===id)||{name:'?',code:'?'}),fa=i=>nm('faculty',i).name,ro=i=>nm('rooms',i).name,ba=i=>nm('batches',i).name,su=i=>nm('subjects',i).code,sl=(d,p)=>`${D[d]} P${p+1}`;
 const add=(ids,msg,t)=>{const k=t+'|'+ids.slice().sort().join();if(!seen.has(k)){seen.add(k);V.push({ids,msg,t})}};
 for(const a of A)for(let j=0;j<a.len;j++)if(a.p+j<6)(by[a.day*6+a.p+j]=by[a.day*6+a.p+j]||[]).push(a);
 for(const q in by){const L=by[q],w=sl(q/6|0,q%6);
  for(let i=0;i<L.length;i++)for(let k=i+1;k<L.length;k++){const a=L[i],b=L[k],ids=[a.id,b.id];
   if(a.fac==b.fac)add(ids,`Faculty clash: ${fa(a.fac)} is double-booked at ${w}: ${su(a.subj)} (${ba(a.batch)}, ${ro(a.room)}) and ${su(b.subj)} (${ba(b.batch)}, ${ro(b.room)})`,'fac');
   if(a.room==b.room)add(ids,`Room clash: ${ro(a.room)} is double-booked at ${w}: ${ba(a.batch)} ${su(a.subj)} and ${ba(b.batch)} ${su(b.subj)}`,'room');
   if(a.batch==b.batch)add(ids,`Batch clash: ${ba(a.batch)} has two classes at ${w}: ${su(a.subj)} and ${su(b.subj)}`,'batch')}}
 const hrs={};
 for(const a of A){const r=S.rooms.find(x=>x.id==a.room),b=S.batches.find(x=>x.id==a.batch),f=S.faculty.find(x=>x.id==a.fac);hrs[a.fac]=(hrs[a.fac]||0)+a.len;
  if(r&&b&&r.cap<b.size)add([a.id],`Room capacity exceeded: ${r.name} seats ${r.cap} but ${b.name} has ${b.size} students (${su(a.subj)})`,'cap');
  if(r&&a.kind=='lab'&&!r.lab)add([a.id],`${su(a.subj)} lab needs lab equipment; ${r.name} is a normal classroom`,'lab');
  if(r&&a.kind=='lec'&&r.lab)add([a.id],`${su(a.subj)} lecture is booked in lab room ${r.name}`,'lab');
  if(f)for(let j=0;j<a.len;j++)if(f.off.includes(a.day*6+a.p+j)){add([a.id],`${f.name} is unavailable on ${sl(a.day,a.p+j)} (${su(a.subj)}, ${ba(a.batch)})`,'avail');break}
  if(a.p+a.len>6||(a.p<S.lunch&&a.p+a.len>S.lunch))add([a.id],`${su(a.subj)} ${a.kind} block runs through the lunch break or past the last period`,'lunch')}
 for(const f of S.faculty)if((hrs[f.id]||0)>f.max)add(A.filter(a=>a.fac==f.id).map(a=>a.id),`Workload exceeded: ${f.name} teaches ${hrs[f.id]}h/week, limit ${f.max}h`,'load');
 return V}
function gini(xs){const n=xs.length,s=xs.reduce((a,b)=>a+b,0);if(!n||!s)return 0;const y=xs.slice().sort((a,b)=>a-b);return 2*y.reduce((a,v,i)=>a+(i+1)*v,0)/(n*s)-(n+1)/n}
