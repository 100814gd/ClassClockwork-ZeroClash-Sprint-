/* User interface: resource editor, timetable grid, drag-and-drop, exports. Needs core.js loaded first. */
const $=s=>document.querySelector(s),esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
let S,A=[],U=[],VIO=[],BAD=new Set(),meta={},hist=[],sel=null,cur={t:'b',id:null},tab='subjects',availFor=null;
const g=(l,id)=>S[l].find(x=>x.id==id)||{name:'?',code:'?'},fn=i=>g('faculty',i).name,rn=i=>g('rooms',i).name,bn=i=>g('batches',i).name;
const hue=id=>(S.subjects.findIndex(s=>s.id==id)*47+190)%360,hr=p=>{const h=9+p+(p>=S.lunch?1:0);return(h>12?h-12:h)+':00'};
const persist=()=>{try{localStorage.setItem('cc.v1',JSON.stringify({S,A,U,meta}))}catch(e){}};
function toast(m,bad){const t=$('#toast');t.textContent=(bad?'⚠ ':'✔ ')+m;t.className='show'+(bad?' bad':'');clearTimeout(toast.h);toast.h=setTimeout(()=>t.className='',bad?5200:2800)}
/* ----- resources panel ----- */
const FIELDS={subjects:[['name','Subject','t'],['code','Code','t'],['lec','Lectures h/wk','n'],['lab','Lab block h','n'],['cr','Credits','n']],faculty:[['name','Name','t'],['max','Max h/wk','n'],['pref','Prefers','p']],rooms:[['name','Room','t'],['cap','Seats','n'],['lab','Lab equipment','c']],batches:[['name','Batch','t'],['size','Students','n']]};
const NEW={subjects:()=>({name:'New subject',code:'NEW',lec:2,lab:0,cr:2,fac:[]}),faculty:()=>({name:'New faculty',max:12,pref:'',off:[]}),rooms:()=>({name:'Room',cap:60,lab:false}),batches:()=>({name:'Batch',size:50})};
function renderTabs(){$('#tabs').innerHTML=Object.keys(FIELDS).map(k=>`<button data-act="tab" data-l="${k}" class="${k==tab?'on':''}">${k[0].toUpperCase()+k.slice(1)} (${S[k].length})</button>`).join('')}
function renderRes(){renderTabs();const l=tab;let h='';
 for(const o of S[l]){h+=`<div class="er">`;
  for(const[k,lb,t]of FIELDS[l]){const a=`data-l="${l}" data-i="${o.id}" data-k="${k}"`;
   h+=`<label>${lb}`+(t=='t'?`<input type="text" ${a} value="${esc(o[k])}">`:t=='n'?`<input type="number" min="0" ${a} value="${o[k]}">`:t=='c'?`<input type="checkbox" ${a} ${o[k]?'checked':''}>`:`<select ${a}>${[['','Any'],['M','Morning'],['A','Afternoon']].map(([v,n])=>`<option value="${v}" ${o[k]==v?'selected':''}>${n}</option>`).join('')}</select>`)+`</label>`}
  if(l=='subjects')h+=`<div class="fc">Faculty: ${S.faculty.map(f=>`<label><input type="checkbox" data-l="subjects" data-i="${o.id}" data-fid="${f.id}" ${o.fac.includes(f.id)?'checked':''}>${esc(f.name)}</label>`).join('')}</div>`;
  if(l=='faculty')h+=`<button data-act="avail" data-i="${o.id}">Availability (${o.off.length} blocked)</button>`;
  h+=`<button data-act="del" data-l="${l}" data-i="${o.id}" aria-label="Delete">Delete</button></div>`;
  if(l=='faculty'&&availFor==o.id)h+=`<div class="er" style="display:block"><small>Tap slots to block/unblock ${esc(o.name)}</small><div class="avg" style="grid-template-columns:36px repeat(6,1fr)">${['']+[0,1,2,3,4,5].map(p=>`<small>P${p+1}</small>`).join('')}${D.map((d,di)=>`<small>${d}</small>`+ALL.map(p=>`<button data-act="slot" data-i="${o.id}" data-s="${di*6+p}" class="${o.off.includes(di*6+p)?'off':''}">${o.off.includes(di*6+p)?'✕':'·'}</button>`).join('')).join('')}</div></div>`}
 $('#res').innerHTML=h+`<button data-act="add" data-l="${l}">+ Add ${l.slice(0,-1).replace('ie','y')}</button>`}
$('#tabs').onclick=$('#res').onclick=e=>{const b=e.target.closest('button');if(!b)return;const a=b.dataset.act,l=b.dataset.l,i=b.dataset.i;
 if(a=='tab'){tab=l;availFor=null}
 else if(a=='add'){S[l].push({id:uid(),...NEW[l]()});if(l=='faculty')S.subjects.forEach(()=>0)}
 else if(a=='avail')availFor=availFor==i?null:+i;
 else if(a=='slot'){const f=g('faculty',i),s=+b.dataset.s;f.off=f.off.includes(s)?f.off.filter(x=>x!=s):[...f.off,s]}
 else if(a=='del'){S[l]=S[l].filter(x=>x.id!=i);if(l=='faculty')S.subjects.forEach(s=>s.fac=s.fac.filter(x=>x!=i));
  const key={subjects:'subj',faculty:'fac',rooms:'room',batches:'batch'}[l];A=A.filter(x=>x[key]!=i);U=U.filter(x=>x[key]!=i)}
 else return;renderRes();refresh()};
$('#res').oninput=e=>{const t=e.target,o=t.dataset.l&&g(t.dataset.l,t.dataset.i);if(!o)return;
 if(t.dataset.fid){const f=+t.dataset.fid;o.fac=t.checked?[...new Set([...o.fac,f])]:o.fac.filter(x=>x!=f)}
 else o[t.dataset.k]=t.type=='checkbox'?t.checked:t.type=='number'?Math.max(0,+t.value||0):t.value;
 if(t.dataset.k=='name'||t.dataset.k=='code'||t.dataset.k=='lab'||t.dataset.k=='lec')hist=[];refresh()};
/* ----- timetable grid ----- */
function gridHTML(t,id,ro){const L=S.lunch,as=A.filter(a=>(t=='b'?a.batch:a.fac)==id);
 let h=`<table class="g"><tr><th class="d"></th>`;for(let p=0;p<6;p++)h+=(p==L?'<th class="lh">Lunch</th>':'')+`<th>P${p+1}<small>${hr(p)}</small></th>`;h+='</tr>';
 for(let d=0;d<5;d++){h+=`<tr><th class="d">${D[d]}</th>`;
  for(let p=0;p<6;p++){h+=(p==L?'<td class="lunch"></td>':'')+`<td class="cell" data-d="${d}" data-p="${p}">`;
   for(const a of as)if(a.day==d&&p>=a.p&&p<a.p+a.len){const s=g('subjects',a.subj),j=p-a.p,bad=BAD.has(a.id),m=VIO.filter(v=>v.ids.includes(a.id)).map(v=>v.msg).join('\n');
    h+=`<div class="chip${a.kind=='lab'?' lab':''}${bad?' bad':''}${sel&&sel.id==a.id?' sel':''}" ${ro?'':'draggable="true"'} data-id="${a.id}" data-j="${j}" style="--h:${hue(a.subj)}" title="${esc(m)}"><b>${bad?'✖ ':''}${esc(s.code)}${a.kind=='lab'?' Lab':''}${a.len>1?` ${j+1}/${a.len}`:''}</b><span>${esc(t=='b'?fn(a.fac):bn(a.batch))}</span><span>${esc(rn(a.room))}</span></div>`}
   h+='</td>'}
  h+='</tr>'}
 return h+'</table>'}
function refresh(){VIO=audit(S,A);BAD=new Set(VIO.flatMap(v=>v.ids));
 const list=S[cur.t=='b'?'batches':'faculty'];if(!list.some(x=>x.id==cur.id))cur.id=list[0]&&list[0].id;
 $('#ent').innerHTML=list.map(x=>`<option value="${x.id}" ${x.id==cur.id?'selected':''}>${esc(x.name)}</option>`).join('');
 $('#vt').querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.dataset.t==cur.t));
 $('#grid').innerHTML=gridHTML(cur.t,cur.id,false);
 const hrs=S.faculty.map(f=>A.filter(a=>a.fac==f.id).reduce((s,a)=>s+a.len,0)),gi=gini(hrs);
 const pf=A.filter(a=>{const f=S.faculty.find(x=>x.id==a.fac);return f&&f.pref});const met=pf.filter(a=>{const f=g('faculty',a.fac);return f.pref=='M'?a.p<S.lunch:a.p>=S.lunch}).length;
 const st=(v,l,c='')=>`<div class="st ${c}"><b>${v}</b>${l}</div>`;
 $('#stats').innerHTML=st(A.length,'classes placed')+st(U.length,'unallocated',U.length?'bad':'good')+st(VIO.length,'clashes',VIO.length?'bad':'good')+st(gi.toFixed(2),'workload Gini (0 = equal)',gi>.3?'bad':'good')+st(pf.length?`${met}/${pf.length}`:'–','preferences met')+st(meta.ms!=null?meta.ms+' ms':'–','solve time');
 $('#aud').innerHTML=VIO.length?VIO.map(v=>`<li class="v">${esc(v.msg)}</li>`).join(''):'<li class="okm">No clashes. All hard constraints are satisfied.</li>';
 $('#un').innerHTML=U.length?U.map(u=>`<li class="u"><b>${esc(bn(u.batch))} · ${esc(g('subjects',u.subj).name)}</b> (${u.kind==='lab'?u.len+'h lab':'lecture'})<br>${esc(u.why)}</li>`).join(''):'<li class="okm">Every class has a slot.</li>';
 $('#wl').innerHTML=S.faculty.map((f,i)=>`<div class="wl"><span>${esc(f.name)}</span><div><i class="${hrs[i]>f.max?'o':''}" style="width:${Math.min(100,f.max?hrs[i]/f.max*100:0)}%"></i></div><span>${hrs[i]}/${f.max}h</span></div>`).join('');
 persist()}
/* ----- move (drag & drop or tap) ----- */
function move(id,j,d,p){const a=A.find(x=>x.id==id);if(!a)return;const np=p-j;
 if(np<0||np+a.len>6){toast(`${g('subjects',a.subj).code} needs ${a.len} consecutive periods; it does not fit there.`,1);return}
 hist.push(JSON.stringify(A));if(hist.length>50)hist.shift();a.day=d;a.p=np;sel=null;refresh();
 const vs=VIO.filter(v=>v.ids.includes(a.id)).sort((x,y)=>(y.t=='fac')-(x.t=='fac'));
 if(vs.length){const v=vs[0],o=A.find(x=>v.ids.includes(x.id)&&x.id!=a.id);toast(v.t=='fac'&&o?`Clash: ${fn(a.fac)} already booked in ${rn(o.room)}`:v.msg,1)}else toast('Moved. No clashes.')}
const grid=$('#grid');
grid.addEventListener('dragstart',e=>{const c=e.target.closest('.chip');if(!c)return;e.dataTransfer.setData('text/plain',c.dataset.id+'|'+c.dataset.j);e.dataTransfer.effectAllowed='move'});
grid.addEventListener('dragover',e=>{const c=e.target.closest('.cell');if(c){e.preventDefault();grid.querySelectorAll('.over').forEach(x=>x.classList.remove('over'));c.classList.add('over')}});
grid.addEventListener('drop',e=>{const c=e.target.closest('.cell');if(!c)return;e.preventDefault();const[id,j]=e.dataTransfer.getData('text/plain').split('|');move(+id,+j,+c.dataset.d,+c.dataset.p)});
grid.addEventListener('dragend',()=>grid.querySelectorAll('.over').forEach(x=>x.classList.remove('over')));
grid.addEventListener('click',e=>{const ch=e.target.closest('.chip'),c=e.target.closest('.cell');
 if(ch&&!(sel&&sel.id==ch.dataset.id)){sel={id:+ch.dataset.id,j:+ch.dataset.j};refresh()}
 else if(sel&&c)move(sel.id,sel.j,+c.dataset.d,+c.dataset.p);else if(sel){sel=null;refresh()}});
$('#undo').onclick=()=>{if(!hist.length)return toast('Nothing to undo.',1);A=JSON.parse(hist.pop());refresh();toast('Move undone.')};
$('#vt').onclick=e=>{const b=e.target.closest('button');if(b){cur={t:b.dataset.t,id:null};refresh()}};
$('#ent').onchange=e=>{cur.id=+e.target.value;refresh()};
$('#lunch').onchange=e=>{S.lunch=+e.target.value;refresh();toast('Lunch break moved. Press Generate Timetable to re-plan around it.')};
/* ----- generate / load ----- */
function generate(){const b=$('#gen');b.textContent='Generating…';setTimeout(()=>{const r=solve(S,1400,(Date.now()%9973)+1);A=r.A;U=r.U;meta=r;hist=[];sel=null;b.textContent='Generate Timetable';refresh();
 toast(U.length?`${U.length} class(es) could not be placed. See the unallocated list.`:`Generated ${A.length} classes in ${r.ms} ms. Zero clashes.`,U.length||VIO.length)},30)}
$('#gen').onclick=generate;
$('#load').onclick=()=>{_id=1;S=preset(+$('#preset').value);$('#lunch').value=S.lunch;A=[];U=[];meta={};cur={t:'b',id:null};tab='subjects';availFor=null;renderRes();generate()};
/* ----- export: PDF, print, iCal ----- */
async function saveFile(name,data){let d=null;try{d=window.claude&&await claude.use('downloads')}catch(e){}
 if(d){try{await d.save({filename:name,data});return}catch(e){if(e&&e.code=='declined')return}}
 const a=document.createElement('a');a.href=URL.createObjectURL(data);a.download=name;document.body.appendChild(a);a.click();a.remove();toast('If nothing downloaded, use Print and choose Save as PDF.',1)}
const rgb=(h,s,l)=>{const a=s*Math.min(l,1-l),f=n=>{const k=(n+h/30)%12;return(l-a*Math.max(-1,Math.min(k-3,9-k,1))).toFixed(3)};return f(0)+' '+f(8)+' '+f(4)};
function makePDF(){const pages=[...S.batches.map(b=>['b',b]),...S.faculty.map(f=>['f',f])],asc=s=>String(s).replace(/[^\x20-\x7e]/g,'?').replace(/([()\\])/g,'\\$1');
 let out='%PDF-1.4\n';const off=[],add=(n,s)=>{off[n]=out.length;out+=`${n} 0 obj\n${s}\nendobj\n`};
 add(1,'<</Type/Catalog/Pages 2 0 R>>');add(2,`<</Type/Pages/Kids[${pages.map((_,i)=>`${5+2*i} 0 R`).join(' ')}]/Count ${pages.length}>>`);add(3,'<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>');add(4,'<</Type/Font/Subtype/Type1/BaseFont/Helvetica-Bold>>');
 const W=[56,...ALL.map(()=>104)],L=S.lunch;
 pages.forEach(([t,o],i)=>{let c='';const T=(x,y,s,z=8,b=0)=>c+=`BT /F${b?2:1} ${z} Tf ${x} ${y} Td (${asc(s)}) Tj ET\n`,R=(x,y,w,h,f)=>c+=f?`${f} rg ${x} ${y} ${w} ${h} re f 0 g\n`:`0.6 G ${x} ${y} ${w} ${h} re S\n`;
  T(40,556,`ClassClockwork  |  ${t=='b'?'Batch':'Faculty'}: ${o.name}`,16,1);T(40,540,`Generated ${new Date().toLocaleDateString()}  |  ${VIO.length?VIO.length+' clash(es) present':'conflict-free'}`,9);
  const xs=[],lx=40+56+104*L;let x=40;const colX=p=>40+56+104*p+(p>=L?26:0);
  R(40,500,56,26);D.forEach((d,di)=>{const y=494-di*62;R(40,y-62,56,62);T(52,y-34,d,11,1)});
  ALL.forEach(p=>{R(colX(p),500,104,26);T(colX(p)+30,512,`P${p+1}  ${hr(p)}`,9,1);D.forEach((_,di)=>R(colX(p),494-di*62-62,104,62))});
  R(lx,500,26,26+0);c+=`0.9 g ${lx} 184 26 342 re f 0 g\n`;T(lx+7,330,'L',9,1);T(lx+7,320,'U',9,1);T(lx+7,310,'N',9,1);T(lx+7,300,'C',9,1);T(lx+7,290,'H',9,1);
  A.filter(a=>(t=='b'?a.batch:a.fac)==o.id).forEach(a=>{const s=g('subjects',a.subj);for(let j=0;j<a.len;j++){const cx=colX(a.p+j),cy=494-a.day*62,k=(a._n=(a._n||0)),bad=BAD.has(a.id);
   if(!j){}const slot=A.filter(z=>(t=='b'?z.batch:z.fac)==o.id&&z.day==a.day&&z.p<=a.p+j&&z.p+z.len>a.p+j),ix=slot.indexOf(a);if(ix>1)continue;const oy=cy-ix*30;
   R(cx+2,oy-30,100,29,bad?'1 0.85 0.85':rgb(hue(a.subj),.6,.88));
   T(cx+5,oy-11,`${s.code}${a.kind=='lab'?' LAB':''}${a.len>1?` ${j+1}/${a.len}`:''}`,8,1);T(cx+5,oy-19,(t=='b'?fn(a.fac):bn(a.batch)).slice(0,24),7);T(cx+5,oy-27,rn(a.room).slice(0,24),7)}});
  const s=c;add(5+2*i,`<</Type/Page/Parent 2 0 R/MediaBox[0 0 842 595]/Resources<</Font<</F1 3 0 R/F2 4 0 R>>>>/Contents ${6+2*i} 0 R>>`);add(6+2*i,`<</Length ${s.length}>>\nstream\n${s}\nendstream`)});
 const n=4+2*pages.length,xr=out.length;out+=`xref\n0 ${n+1}\n0000000000 65535 f \n`+off.slice(1,n+1).map(o=>String(o).padStart(10,'0')+' 00000 n \n').join('')+`trailer\n<</Size ${n+1}/Root 1 0 R>>\nstartxref\n${xr}\n%%EOF`;
 return new Blob([new TextEncoder().encode(out)],{type:'application/pdf'})}
$('#pdf').onclick=()=>{if(!A.length)return toast('Generate a timetable first.',1);saveFile('timetables.pdf',makePDF())};
$('#print').onclick=()=>{try{window.print()}catch(e){toast('Printing is blocked here. Use Export PDF instead.',1)}};
addEventListener('beforeprint',()=>{$('#pa').innerHTML=[...S.batches.map(b=>['b',b]),...S.faculty.map(f=>['f',f])].map(([t,o])=>`<section><h2>${t=='b'?'Batch':'Faculty'}: ${esc(o.name)}</h2>${gridHTML(t,o.id,true)}</section>`).join('')});
addEventListener('afterprint',()=>$('#pa').innerHTML='');
$('#ics').onclick=()=>{const as=A.filter(a=>(cur.t=='b'?a.batch:a.fac)==cur.id);if(!as.length)return toast('Nothing to export for this selection.',1);
 const d=new Date();d.setDate(d.getDate()+((8-d.getDay())%7||7));const z=n=>String(n).padStart(2,'0'),ymd=x=>`${x.getFullYear()}${z(x.getMonth()+1)}${z(x.getDate())}`,stamp=new Date().toISOString().replace(/[-:]|\.\d+/g,''),ic=s=>String(s).replace(/([,;\\])/g,'\\$1');
 const nm=g(cur.t=='b'?'batches':'faculty',cur.id).name;let o=`BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//ClassClockwork//EN\r\nX-WR-CALNAME:${ic(nm)} timetable\r\n`;
 for(const a of as){const x=new Date(d);x.setDate(d.getDate()+a.day);const h=p=>9+p+(p>=S.lunch?1:0),s=g('subjects',a.subj);
  o+=`BEGIN:VEVENT\r\nUID:${a.id}-${cur.id}@classclockwork\r\nDTSTAMP:${stamp}\r\nDTSTART:${ymd(x)}T${z(h(a.p))}0000\r\nDTEND:${ymd(x)}T${z(h(a.p+a.len-1)+1)}0000\r\nRRULE:FREQ=WEEKLY;COUNT=16\r\nSUMMARY:${ic(s.name+(a.kind=='lab'?' (Lab)':''))}\r\nLOCATION:${ic(rn(a.room))}\r\nDESCRIPTION:${ic(cur.t=='b'?'Faculty: '+fn(a.fac):'Batch: '+bn(a.batch))}\r\nEND:VEVENT\r\n`}
 saveFile(nm.replace(/\W+/g,'_')+'.ics',new Blob([o+'END:VCALENDAR\r\n'],{type:'text/calendar'}))};
/* ----- boot ----- */
(function(){let ok=false;try{const j=JSON.parse(localStorage.getItem('cc.v1'));if(j&&j.S&&j.S.subjects){S=j.S;A=j.A||[];U=j.U||[];meta=j.meta||{};
  _id=1+Math.max(0,...Object.values(S).flat().map(x=>x&&x.id||0),...A.map(a=>a.id));$('#lunch').value=S.lunch;ok=true}}catch(e){}
 if(!ok){S=preset(1);renderRes();generate();return}renderRes();refresh()})();
