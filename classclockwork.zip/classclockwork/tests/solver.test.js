// Run with:  node tests/solver.test.js
const fs = require('fs'), path = require('path'), assert = require('assert');
const src = fs.readFileSync(path.join(__dirname, '../js/core.js'), 'utf8');
const { preset, solve, audit, gini } = new Function(src + ';return{preset,solve,audit,gini}')();

for (const n of [1, 2]) {
  const S = preset(n);
  for (let seed = 1; seed <= 5; seed++) {
    const r = solve(S, 1400, seed * 13);
    assert.strictEqual(r.U.length, 0, `preset ${n}: all classes placed`);
    assert.strictEqual(audit(S, r.A).length, 0, `preset ${n}: no clashes`);
    assert.ok(r.ms < 1500, `preset ${n}: solved under 1.5 s`);
  }
  console.log(`preset ${n}: OK`);
}
// forced clash must be detected
const S = preset(2), A = solve(S, 1400, 5).A;
const a = A.find(x => x.len === 1), b = A.find(x => x.fac === a.fac && x.id !== a.id && x.batch !== a.batch && x.len === 1);
a.day = b.day; a.p = b.p;
assert.ok(audit(S, A).some(v => v.t === 'fac'), 'faculty clash detected');
// impossible config degrades gracefully
const S3 = preset(2); S3.rooms = S3.rooms.filter(r => !r.lab);
const r3 = solve(S3, 1400, 1);
assert.ok(r3.U.length > 0 && r3.A.length > 0, 'unallocated classes reported, no crash');
assert.ok(Math.abs(gini([5, 5, 5])) < 1e-9 && gini([0, 0, 10]) > 0.6, 'gini');
console.log('all tests passed');
